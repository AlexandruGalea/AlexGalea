package HotelManagementSystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class AdminPage extends JFrame implements ActionListener{
	JButton b1,b2,b3,b4,b5,b6,b7;
	
	AdminPage(){
	
        setBounds(400,200,750,500);
		
		
	
		b1 = new JButton("ADD ROOM");
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.addActionListener(this);
		b1.setBounds(10,20,200,30);
		add(b1);
		
		b2 = new JButton("DELETE ROOM");
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		b2.addActionListener(this);
		b2.setBounds(10,60,200,30);
		add(b2);
		
		b3 = new JButton("ADD FOOD");
		b3.setBackground(Color.black);
		b3.setForeground(Color.white);
		b3.addActionListener(this);
		b3.setBounds(10,100,200,30);
		add(b3);
		
		b4 = new JButton("DELETE FOOD");
		b4.setBackground(Color.black);
		b4.setForeground(Color.white);
		b4.addActionListener(this);
		b4.setBounds(10,140,200,30);
		add(b4);
		
		b5 = new JButton("CUSTOMERS INFO");
		b5.setBackground(Color.black);
		b5.setForeground(Color.white);
		b5.addActionListener(this);
		b5.setBounds(10,180,200,30);
		add(b5);
		
		b6 = new JButton("ROOMS INFO");
		b6.setBackground(Color.black);
		b6.setForeground(Color.white);
		b6.addActionListener(this);
		b6.setBounds(10,220,200,30);
		add(b6);
		
		b7 = new JButton("EXIT");
		b7.setBackground(Color.black);
		b7.setForeground(Color.white);
		b7.addActionListener(this);
		b7.setBounds(10,260,200,30);
		add(b7);
	    
	    
	    
		ImageIcon i5 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/administrator.png"));
	    JLabel l9= new JLabel(i5);
	    getContentPane().setBackground(Color.white);
	    l9.setBounds(500,250,300,300);
	    add(l9);
	    setLayout(null);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==b1)
			new AddRooms().setVisible(true);	
		else
		if(ae.getSource()==b2)
			new DeleteRoom().setVisible(true);
			
		else
		if(ae.getSource()==b3)
			new AddFood().setVisible(true);
		else
		if(ae.getSource()==b4)
			new DeleteFood().setVisible(true);
		else
		if(ae.getSource()==b5)
			new CustomerInfo().setVisible(true);
	    else
		if(ae.getSource()==b6)
			new Room().setVisible(true);
		else
		if(ae.getSource()==b7)
			System.exit(0);
	
			dispose();
		
		
	}
	
	

}
