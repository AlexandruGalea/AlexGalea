package HotelManagementSystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class AddFood extends JFrame implements ActionListener{
	
	JTextField t1,t2;
	JButton b1,b2;
	AddFood(){
		setBounds(400,200,750,500);
		JLabel l1 = new JLabel("Add Food");
		l1.setFont(new Font("Tohoma",Font.BOLD,21));
		l1.setBackground(Color.red);
		l1.setOpaque(true);
		l1.setBounds(480,15,120,30);
		add(l1);
		
		JLabel food = new JLabel("Food name");
		food.setFont(new Font("Tohoma",Font.BOLD,14));
		food.setForeground(Color.red);
		food.setBounds(420,120,120,30);
		add(food);
		
		t1 = new JTextField();
		t1.setBounds(560,120,110,30);
		add(t1);
		
		JLabel price = new JLabel("Price");
		price.setFont(new Font("Tohoma",Font.BOLD,14));
		price.setForeground(Color.red);
		price.setBounds(420,160,120,30);
		add(price);
		
		t2 = new JTextField();
		t2.setBounds(560,160,110,30);
		add(t2);
		
		
		b1  = new JButton("Add Food");
		b1.setBounds(423,300,100,30);
		b1.addActionListener(this);
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		add(b1);
		
		
		b2  = new JButton("Cancel");
		b2.setBounds(565,300,100,30);
		b2.addActionListener(this);
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		add(b2);
		
		
		
	
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/food.jpg"));
		JLabel l2 = new JLabel(i1);
		l2.setBounds(0,0,750,500);
		add(l2);
		
		setLayout(null);
		setVisible(true);
		
	}
	
	
	public void actionPerformed(ActionEvent ae) {
		
if(ae.getSource()==b1) {
			
			String name = t1.getText();
			String price = t2.getText();
			
			database c = new database();
			try {
				
				String str = "insert into food values('"+name+"','"+price+"')";
				c.s.executeUpdate(str);
				
				JOptionPane.showMessageDialog(null,"New Food Added");
				
				
			}catch(Exception e) {
				System.out.println(e);
			}
}
			
	
			new AdminPage().setVisible(true);
			dispose();
		
	}		
	

}
