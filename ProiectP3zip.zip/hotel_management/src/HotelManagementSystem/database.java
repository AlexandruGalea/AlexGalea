package HotelManagementSystem;


import java.sql.*;

public class database {

	Connection c;
	Statement s;
	
	public database() {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			c = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_management?autoReconnect=true&useSSL=false","root","");
			s = c.createStatement();		
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
