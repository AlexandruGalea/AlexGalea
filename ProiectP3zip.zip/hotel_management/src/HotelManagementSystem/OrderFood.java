package HotelManagementSystem;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.*;


public class OrderFood extends JFrame implements ActionListener{
	
	Choice c0,c1;
	JButton b1,b2;
	JTextField t1;
	OrderFood(){
		
	setBounds(270,100,900,650);
	
	
	
	JLabel l5 = new JLabel("Room Number");
	l5.setFont(new Font("Tohoma",Font.BOLD,14));
	l5.setForeground(Color.white);;
	l5.setBounds(550,200,100,30);
	add(l5);
	
     c0= new Choice();
	
	try {
		
		database c = new database();
		ResultSet rs = c.s.executeQuery("select * from room where availability = 'Occupied'");
		while(rs.next()) {
			c0.add(rs.getString("room_number"));
		}
		
	}catch(Exception e) {
		System.out.println(e);
	}
	c0.setBounds(670,205,200,30);
	
	add(c0);
	
	
	JLabel l1 = new JLabel("Food ");
	l1.setFont(new Font("Tohoma",Font.BOLD,14));
	l1.setForeground(Color.white);
	l1.setBounds(550,300,120,30);
	add(l1);
	
	
    c1 = new Choice();
	
	try {
		
		database c = new database();
		ResultSet rs = c.s.executeQuery("select * from food ");
		while(rs.next()) {
			c1.add(rs.getString("name")+"-"+rs.getString("price")+"$");
		}
		
	}catch(Exception e) {
		System.out.println(e);
	}
	c1.setBounds(670,305,200,30);
	
	add(c1);
	
	
	
	b1  = new JButton("Order");
	b1.setBounds(550,400,100,30);
	b1.addActionListener(this);
	b1.setBackground(Color.black);
	b1.setForeground(Color.white);
	add(b1);
	
	
	b2  = new JButton("Cancel");
	b2.setBounds(700,400,100,30);
	b2.addActionListener(this);
	b2.setBackground(Color.black);
	b2.setForeground(Color.white);
	add(b2);
	
	ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/menu.png"));
	Image i2 = i1.getImage().getScaledInstance(1000, 650, Image.SCALE_DEFAULT);
	ImageIcon i3 = new ImageIcon(i2);
	JLabel l3 = new JLabel(i3);
	l3.setBounds(0,0,900,650);
	add(l3);
	setLayout(null);
	setVisible(true);
	
	
	}
	public String method(String str) {
	    if (str != null && str.length() > 0 ) {
	        str = str.substring(0, str.length() - 1);
	    }
	    return str;
	}
	
	
	
	public void actionPerformed(ActionEvent ae) {
		
		
		if(ae.getSource()==b1)
		{
			
			String room = c0.getSelectedItem();
			String order= c1.getSelectedItem();
			String[] parts = order.split("-");
			String aux= method(parts[1]);
			
			String topay = "select payment from bill where room_number = '"+room+"'";
			 try {
					
					database c = new database();
					ResultSet rs = c.s.executeQuery(topay);
					while(rs.next()) {
						topay=rs.getString("payment");
					}
					
				}catch(Exception e) {
					System.out.println(e);
				}
		     int number=0,number2=0,total=0;
		     
		     
			try{
	             number = Integer.parseInt(topay);
	             number2= Integer.parseInt(aux);
	             total= number+ number2;
	        } catch (NumberFormatException e){
	            e.printStackTrace();
	        }
			 
			String s=String.valueOf(total);
			
		    String str= "update bill set payment='"+s+"' where room_number='"+room+"'";
            try {
				
				database c = new database();
				c.s.executeUpdate(str);
				
				JOptionPane.showMessageDialog(null, "Order placed");
				
				
			}catch(Exception e) {
				System.out.println(e);
			}
		}
		else
		{
			new WelcomePage().setVisible(true);
			dispose();
		}
		
	}
	
}