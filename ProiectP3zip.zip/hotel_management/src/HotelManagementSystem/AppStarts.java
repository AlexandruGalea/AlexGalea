package HotelManagementSystem;

import java.awt.event.WindowEvent;

import javax.swing.*;

public class AppStarts extends JFrame{
     
	
	AppStarts(){
        setBounds(300,130,900,600);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/hotel2.jpg"));
		JLabel l1 = new JLabel(i1);
		l1.setBounds(0,0,900,600);
		add(l1);
		setLayout(null);
		setVisible(true);
		
		try
		{
		    Thread.sleep(3000);
		}
		catch(InterruptedException ex)
		{
		    Thread.currentThread().interrupt();
		}
		new WelcomePage().setVisible(true);
		dispose();
	}
	public static void main(String[] args) {
		
      new AppStarts();
      
	}
	
	

}
