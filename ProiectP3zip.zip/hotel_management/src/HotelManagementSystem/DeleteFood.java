package HotelManagementSystem;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.*;


public class DeleteFood extends JFrame implements ActionListener{
	
	Choice c1;
	JButton b1,b2;
	DeleteFood(){
		setBounds(400,200,600,300);
		JLabel l1 = new JLabel("Delete Food");
		l1.setFont(new Font("Tohoma",Font.BOLD,21));
		l1.setBackground(Color.red);
		l1.setOpaque(true);
		l1.setBounds(350,15,150,30);
		add(l1);
		
		JLabel food = new JLabel("Food name");
		food.setFont(new Font("Tohoma",Font.BOLD,14));
		food.setForeground(Color.black);
		food.setBounds(250,70,120,30);
		add(food);
		
		
        c1 = new Choice();
		
		try {
			
			database c = new database();
			ResultSet rs = c.s.executeQuery("select * from food");
			while(rs.next()) {
				c1.add(rs.getString("name"));
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
		c1.setBounds(400,70,110,30);
		add(c1);
		
		
		
		b1  = new JButton("Delete Food");
		b1.setBounds(200,200,100,30);
		b1.addActionListener(this);
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		add(b1);
		
		
		b2  = new JButton("Cancel");
		b2.setBounds(360,200,100,30);
		b2.addActionListener(this);
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		add(b2);
		getContentPane().setBackground(Color.white);
		
		setLayout(null);
		setVisible(true);
		
	}
	
	
	public void actionPerformed(ActionEvent ae) {
		
          if(ae.getSource()==b1) {
			
			
			String name = c1.getSelectedItem();
		
			String str = "delete from food where name = '"+name+"'";
			
			try {
				
				database c = new database();
				c.s.executeUpdate(str);
				JOptionPane.showMessageDialog(null, "Delete successful");
			
				
				
			}catch(Exception e) {
				System.out.println(e);
			}
          }
			
		new AdminPage().setVisible(true);
         dispose();
		
		
	}

}