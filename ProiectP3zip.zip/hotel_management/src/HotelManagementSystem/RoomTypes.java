package HotelManagementSystem;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.*;


public class RoomTypes extends JFrame implements ActionListener{
	
	JButton b1,b2,b3;
	JLabel l1,l2;
	JTextArea t1,t2;
	RoomTypes()
	{
		setBounds(300,130,900,600);
		
		b1= new JButton("Simple Room");
		b1.setBounds(0,5,120,30);
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.addActionListener(this);
		add(b1);
		
		b2= new JButton("Luxury Room");
		b2.setBounds(120,5,120,30);
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		b2.addActionListener(this);
		add(b2);
	    b3  = new JButton("Back");
		b3.setBounds(400,530,100,30);
		b3.addActionListener(this);
		b3.setBackground(Color.white);
		b3.setForeground(Color.black);
		add(b3);
		
		JTextArea t1= new JTextArea();
		t1.setBounds(800,30,80,70);
		t1.append("Facilities\n-TV\n-Balcony");
		t1.setFont(new Font("Tohoma",Font.BOLD,16));
		t1.setForeground(Color.green);
		t1.setOpaque(false);
		
		
		JTextArea t2= new JTextArea();
		t2.setBounds(800,30,80,90);
		t2.append("Facilities\n-TV\n-AC\n-Minibar");
		t2.setFont(new Font("Tohoma",Font.BOLD,16));
		t2.setForeground(Color.green);
		t2.setOpaque(false);
		
		
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/simpleroom.jpg"));
		Image i2 = i1.getImage().getScaledInstance(900, 550, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		l1= new JLabel(i3);
		l1.setBounds(0,35,900,550);
        add(l1);
        l1.add(t1);
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/luxuryroom.jpg"));
		Image i5 = i4.getImage().getScaledInstance(900, 550, Image.SCALE_DEFAULT);
		ImageIcon i6 = new ImageIcon(i5);
		l2= new JLabel(i6);
		l2.setBounds(0,35,900,550);
        add(l2);
        l2.add(t2);
        l2.setVisible(false);
        getContentPane().setBackground(Color.WHITE);
		setLayout(null);
		setVisible(true);
		
	}
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==b1)
		{
			l1.setVisible(true);
			l2.setVisible(false);
		}
		else
			if(ae.getSource()==b2)
			{
				l2.setVisible(true);
				l1.setVisible(false);
			}
		else
			if(ae.getSource()==b3)
			{
				new WelcomePage().setVisible(true);
				dispose();
			}
				
		
		
	}

}
