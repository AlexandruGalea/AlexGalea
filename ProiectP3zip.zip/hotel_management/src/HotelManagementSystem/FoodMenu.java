package HotelManagementSystem;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;

import net.proteanit.sql.DbUtils;

public class FoodMenu extends JFrame implements ActionListener{
	
	JTable t1;
	JButton b1,b2;
	FoodMenu(){
		setBounds(270,100,1000,650);
		
		JLabel l1 = new JLabel("Food Name");
		l1.setBounds(10,10,80,30);
		l1.setForeground(Color.green);
		add(l1);	
		JLabel l2 = new JLabel("Price");
		l2.setBounds(300,10,50,30);
		l2.setForeground(Color.green);
		add(l2);
		
		
		t1 = new JTable();
		t1.setBounds(0,40,550,500);
		add(t1);
		
		b1 = new JButton("Load Data");
		b1.addActionListener(this);
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.setBounds(130,560,120,30);
		add(b1);
		
		b2 = new JButton("Back");
		b2.addActionListener(this);
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		b2.setBounds(300,560,120,30);
		add(b2);
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/menu.png"));
		Image i2 = i1.getImage().getScaledInstance(1000, 650, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel l3 = new JLabel(i3);
		l3.setBounds(0,0,1000,650);
		add(l3);
		
		
		setLayout(null);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent ae) {
if(ae.getSource()==b1) {
			
			
			try {
				
				database c = new database();				
				String str = "select * from food";				
				ResultSet rs = c.s.executeQuery(str); 
				
				t1.setModel(DbUtils.resultSetToTableModel(rs));
				
				
			}catch(Exception e) {
				System.out.println(e);
			}
			
			
			
		}else if(ae.getSource()==b2) {
			new WelcomePage().setVisible(true);
			dispose();
		}
		
	}
	
	
	
}
