package HotelManagementSystem;


import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;


public class CheckOut extends JFrame implements ActionListener{

	
	Choice c1;
	JTextField t1,t2;
	JButton b1,b2,b3;	
	
	
	
	CheckOut(){
		
		
		JLabel l1 = new JLabel("Check Out");
		l1.setFont(new Font("Tohoma",Font.BOLD,20));
		l1.setForeground(Color.blue);
		l1.setBounds(30,20,150,30);
		add(l1);
		
		
		JLabel l2 = new JLabel("Customer Id");
		l2.setBounds(30,70,100,30);
		add(l2);
		
		c1 = new Choice();
		
		try {
			
			database c = new database();
			ResultSet rs = c.s.executeQuery("select * from customer");
			while(rs.next()) {
				c1.add(rs.getString("number"));
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
		c1.setBounds(200,70,120,30);
		add(c1);
		
		JLabel l3 = new JLabel("Room Number");
		l3.setBounds(30,120,100,30);
		add(l3);
		
		
		t1 = new JTextField();
		t1.setBounds(200,120,120,30);
		add(t1);
		
		JLabel l4= new JLabel("No. of days");
		l4.setBounds(30,180,100,30);
		add(l4);
		
		t2 = new JTextField();
		t2.setBounds(200,180,120,30);
		add(t2);
		
		
		
		
		b1 = new JButton("CheckOut");
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.addActionListener(this);
		b1.setBounds(30,250,120,30);
		add(b1);
		
		
		b2 = new JButton("Cancel");
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		b2.addActionListener(this);
		b2.setBounds(200,250,120,30);
		add(b2);
		
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/tick.png"));
		Image i2 = i1.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		b3 = new JButton(i3);
		b3.addActionListener(this);
		b3.setBounds(340,60,30,30);
		add(b3);
		
		ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/checkout2.jpeg"));
		Image i5 = i4.getImage().getScaledInstance(400, 200, Image.SCALE_DEFAULT);
		ImageIcon i6 = new ImageIcon(i5);
		JLabel lii = new JLabel(i6);
		lii.setBounds(380,30,400,200);
		add(lii);
		
		getContentPane().setBackground(Color.white);
		
		setLayout(null);
		setBounds(400,200,800,350);
		setVisible(true);
		
	}
	
	
	public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==b1) {
			
			String id = c1.getSelectedItem();
			String room = t1.getText();
			String s= "select price from room where room_number='"+room+"'";
		    String s2 = "select payment from bill where room_number = '"+room+"'";
			
			try {
				
				database c = new database();
				ResultSet rs = c.s.executeQuery(s);
				while(rs.next()) {
					s=rs.getString("price");
				}
				
				ResultSet r = c.s.executeQuery(s2);
				while(r.next()) {
					s2=r.getString("payment");
				}
				
				
			}catch(Exception e) {
				System.out.println(e);
			}
				
			String days= t2.getText();
			int nodays=0, price=0,total=0,food=0;
			try{
	             nodays = Integer.parseInt(days);
	             price= Integer.parseInt(s);
	             food=Integer.parseInt(s2);
	             total= (nodays*price)+ food;
	             
	        } catch (NumberFormatException e){
	            e.printStackTrace();
	        }
			String str = "delete from customer where number = '"+id+"'";
			String str1 = "delete from bill where customer_id = '"+id+"'";
			String str2 = "update room set availability = 'Available' where room_number = '"+room+"'";
			
			try {
				
				database c = new database();
				c.s.executeUpdate(str);
				c.s.executeUpdate(str1);
				c.s.executeUpdate(str2);
				JOptionPane.showMessageDialog(null, "You have to pay "+total+"$");
				new WelcomePage().setVisible(true);
				dispose();
				
			}catch(Exception e) {
				System.out.println(e);
			}
			
			
		}else if (ae.getSource()==b2) {
			
			new WelcomePage().setVisible(true);
			dispose();
			
		}else if(ae.getSource()==b3) {
			
			String id = c1.getSelectedItem();
			try {
				
				database c = new database();
				ResultSet rs = c.s.executeQuery("select * from customer where number  = '"+id+"'");
				while(rs.next()) {
					t1.setText(rs.getString("room"));
				}
				
			}catch(Exception e) {
				System.out.println(e);
			}
			
			
		}
		
	}
	
	


}
