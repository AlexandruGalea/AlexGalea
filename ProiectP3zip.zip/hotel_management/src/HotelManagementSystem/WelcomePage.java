package HotelManagementSystem;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class WelcomePage extends JFrame implements ActionListener{
	
	JButton b1,b2,b3,b4,b5,b6,b7,b8;
	
	WelcomePage(){
	    
		setBounds(300,130,900,600);
		
		
		
		JLabel l2=new JLabel();
		l2.setBounds(0,0,900,600);
		l2.setBackground(Color.black);
		add(l2);
	
		
		ImageIcon i2 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/admin.jpg"));
		Image i3 = i2.getImage().getScaledInstance(80, 80, Image.SCALE_DEFAULT);
		ImageIcon i4 = new ImageIcon(i3);
		b1 = new JButton(i4);
		b1.setBounds(750,450,80,80);
		b1.addActionListener(this);
		l2.add(b1);
		l2.setVisible(true);
		b2 = new JButton("Book a room");
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		b2.addActionListener(this);
		b2.setBounds(10,30,200,30);
		l2.add(b2);
		
		
		b3 = new JButton("Room types");
		b3.setBackground(Color.black);
		b3.setForeground(Color.white);
		b3.addActionListener(this);
		b3.setBounds(10,80,200,30);
		l2.add(b3);
		
		
		
		
		
		b4 = new JButton("Search room");
		b4.setBackground(Color.black);
		b4.setForeground(Color.white);
		b4.addActionListener(this);
		b4.setBounds(10,130,200,30);
		l2.add(b4);
		
		
		
		
		
		b5 = new JButton("Food menu");
		b5.setBackground(Color.black);
		b5.setForeground(Color.white);
		b5.addActionListener(this);
		b5.setBounds(10,180,200,30);
		l2.add(b5);
		
		
		
		b6 = new JButton("Order food");
		b6.setBackground(Color.black);
		b6.setForeground(Color.white);
		b6.addActionListener(this);
		b6.setBounds(10,230,200,30);
		l2.add(b6);
		
		b7 = new JButton("Check out");
		b7.setBackground(Color.black);
		b7.setForeground(Color.white);
		b7.addActionListener(this);
		b7.setBounds(10,280,200,30);
		l2.add(b7);
		
		b8 = new JButton("Exit");
		b8.setBackground(Color.black);
		b8.setForeground(Color.white);
		b8.addActionListener(this);
		b8.setBounds(10,330,200,30);
		l2.add(b8);
		
		ImageIcon i5 = new ImageIcon(ClassLoader.getSystemResource("HotelManagementSystem/icons/welcome.jpg"));
		Image i6 = i5.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
		ImageIcon i7 = new ImageIcon(i6);
	    JLabel l9= new JLabel(i7);
	    l9.setBounds(0,0,900,600);
	    add(l9);
	   
	   
		setLayout(null);
		setVisible(true);
		
		
       
		
		
		
	}
	
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==b1)
		  new Login().setVisible(true);
	else if(ae.getSource() == b2) 
		 new AddCustomer().setVisible(true);
		
		else if(ae.getSource() == b3) 
			new RoomTypes().setVisible(true);
		
		
	else if(ae.getSource() == b4) 
		new SearchRoom().setVisible(true);
		
		
	else if(ae.getSource() == b5) 
		
		new FoodMenu().setVisible(true);
		
		
	else if(ae.getSource() == b6) 
		
		new OrderFood().setVisible(true);
	else if( ae.getSource() == b7)
		new CheckOut().setVisible(true);
	else if(ae.getSource() ==b8)
		System.exit(0);
		
	
		
		
		
		dispose();
	}


}